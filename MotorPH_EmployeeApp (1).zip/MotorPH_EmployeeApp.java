
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;

public class MotorPH_EmployeeApp extends JFrame {
    private JTextField idField, nameField, deptField;
    private JButton addButton, updateButton, deleteButton, saveButton;
    private JTable employeeTable;
    private DefaultTableModel tableModel;

    private ArrayList<Employee> employeeList = new ArrayList<>();

    public MotorPH_EmployeeApp() {
        setTitle("MotorPH Employee Management");
        setSize(700, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        idField = new JTextField();
        nameField = new JTextField();
        deptField = new JTextField();

        formPanel.add(new JLabel("Employee ID:"));
        formPanel.add(idField);
        formPanel.add(new JLabel("Full Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Department:"));
        formPanel.add(deptField);

        addButton = new JButton("Add Employee");
        updateButton = new JButton("Update Employee");
        deleteButton = new JButton("Delete Employee");

        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);

        formPanel.add(addButton);
        formPanel.add(updateButton);

        // Table
        String[] columnNames = {"Employee ID", "Full Name", "Department"};
        tableModel = new DefaultTableModel(columnNames, 0);
        employeeTable = new JTable(tableModel);
        JScrollPane tableScroll = new JScrollPane(employeeTable);

        // Buttons
        JPanel bottomPanel = new JPanel();
        saveButton = new JButton("Save to CSV");
        bottomPanel.add(deleteButton);
        bottomPanel.add(saveButton);

        // Layout
        setLayout(new BorderLayout(10, 10));
        add(formPanel, BorderLayout.NORTH);
        add(tableScroll, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Events
        addButton.addActionListener(e -> addEmployee());
        updateButton.addActionListener(e -> updateEmployee());
        deleteButton.addActionListener(e -> deleteEmployee());
        saveButton.addActionListener(e -> saveToCSV());

        employeeTable.getSelectionModel().addListSelectionListener(e -> {
            int row = employeeTable.getSelectedRow();
            if (row >= 0) {
                idField.setText((String) tableModel.getValueAt(row, 0));
                nameField.setText((String) tableModel.getValueAt(row, 1));
                deptField.setText((String) tableModel.getValueAt(row, 2));
                updateButton.setEnabled(true);
                deleteButton.setEnabled(true);
            }
        });
    }

    private void addEmployee() {
        String id = idField.getText();
        String name = nameField.getText();
        String dept = deptField.getText();
        if (id.isEmpty() || name.isEmpty() || dept.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled.");
            return;
        }
        tableModel.addRow(new String[]{id, name, dept});
        employeeList.add(new Employee(id, name, dept));
        clearFields();
    }

    private void updateEmployee() {
        int row = employeeTable.getSelectedRow();
        if (row >= 0) {
            String id = idField.getText();
            String name = nameField.getText();
            String dept = deptField.getText();
            tableModel.setValueAt(id, row, 0);
            tableModel.setValueAt(name, row, 1);
            tableModel.setValueAt(dept, row, 2);
            employeeList.set(row, new Employee(id, name, dept));
            clearFields();
            updateButton.setEnabled(false);
            deleteButton.setEnabled(false);
        }
    }

    private void deleteEmployee() {
        int row = employeeTable.getSelectedRow();
        if (row >= 0) {
            tableModel.removeRow(row);
            employeeList.remove(row);
            clearFields();
            updateButton.setEnabled(false);
            deleteButton.setEnabled(false);
        }
    }

    private void saveToCSV() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("MotorPH_Employees.csv"))) {
            for (Employee emp : employeeList) {
                writer.println(emp.getId() + "," + emp.getName() + "," + emp.getDept());
            }
            JOptionPane.showMessageDialog(this, "Data saved to MotorPH_Employees.csv");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        deptField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MotorPH_EmployeeApp().setVisible(true));
    }
}

class Employee {
    private String id;
    private String name;
    private String dept;

    public Employee(String id, String name, String dept) {
        this.id = id;
        this.name = name;
        this.dept = dept;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getDept() { return dept; }
}
